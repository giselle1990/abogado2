Preentrega 3 Comisión 56065


Nombre y apellido: Giselle San German



Resumen del proyecto: seria una pagina web para crear datos de clientes de estudio juridico dedicado a gestionar deudas o sacar de bases de datos como VERAZ, NOSIS, etc. Hice algo de este estilo ya que soy abogada. 

Pasos para ejecutar el proyecto

Link de GitHub
https://github.com/giselle1990/LinkMiPrimeraPagina-SanGerman

Las dependencias que se usaron: Django 5.1

Cómo ejecutar la aplicación web en el servidor local